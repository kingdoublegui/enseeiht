- comptage des mots d'un répertoire : find+grep par fork/join (version récursive)
- données : tableaux générés pat GCVT (non intégrés à l'archive)
- exemples énoncé : contient le source des exemples de l'énoncé, avec des variantes complémentaires
 (FJG : exemple ForkJoin, pool fixe : exemple somme)
- FJP_README.html : sujet (format html)
- FJP_README.md :  : sujet (format markdown)
- max : calcul du maximum d'un tableau (version séquentielle) + utilitaire de gestion de tableaux (GCVT)
- plus loin : exercices d'approfondissement pour fork/join, (source : https://github.com/aradzie/sudoku)
- tri fusion : version récursive + GCVT